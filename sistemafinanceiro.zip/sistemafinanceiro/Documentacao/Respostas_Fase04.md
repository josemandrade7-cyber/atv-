# Fase 04 – Filosofando

**01. Por que é fundamental que o teste falhe (Red) antes de escrevermos o código da `EmprestimoService`? O que essa falha nos garante?**

A falha prova que o teste é capaz de detectar a ausência do comportamento. Se ele passasse antes de existir qualquer implementação, estaria mal escrito: um `Assert` que nunca falha, um cenário errado ou o código errado sendo testado. Quando o teste fica verde depois, sabemos que foi o código novo que o fez passar. O Red também obriga a definir o resultado esperado (R$ 1.000,00 a 10% = R$ 1.100,00) antes de pensar na solução. No projeto, o Red foi um erro de compilação (CS0246), porque a classe `EmprestimoService` ainda não existia.

**02. Como o "contrato" definido pela interface `IEmprestimoService` ajuda quando vários desenvolvedores trabalham ao mesmo tempo?**

A interface fixa o nome do método, os parâmetros e o tipo de retorno antes da implementação. Com isso, cada pessoa trabalha em paralelo: uma faz a Controller e a tela chamando `IEmprestimoService`, outra implementa a `EmprestimoService` e outra escreve os testes. Enquanto a implementação não fica pronta, quem depende dela pode usar um *mock* ou *stub*. A implementação pode ser trocada sem afetar quem a usa, por exemplo com injeção de dependência (`builder.Services.AddScoped<IEmprestimoService, EmprestimoService>()`). E se alguém mudar o contrato, a compilação quebra em todos os pontos afetados, o que deixa a mudança visível para a equipe.

**03. Qual a vantagem de manter os testes em um projeto separado, em vez de colocá-los na mesma pasta das Models?**

O código de teste e suas dependências (xUnit, Test SDK, coverlet) não vão para a publicação da aplicação web, que fica menor e mais segura. A organização fica clara: o projeto principal contém só regra de negócio e apresentação, e o projeto de testes contém só verificações. Como o teste referencia o projeto principal "de fora", ele usa apenas o que é público, o que mostra se o código é fácil de usar por outras partes do sistema. Também é possível rodar só os testes (`dotnet test`) em um pipeline de integração contínua, sem subir a aplicação nem o banco.

**04. Se a regra mudasse de juros simples para compostos e o código estivesse direto na Controller (sem Services nem interfaces), qual seria a dificuldade de testar a nova regra?**

A Controller depende do ASP.NET (requisição, `View`) e do `AppDbContext` com SQL Server. Para testar o cálculo seria preciso criar a Controller, um banco ou um contexto falso, ou testar manualmente pela tela, o que é lento, frágil e difícil de repetir. A regra ficaria misturada com a lógica de apresentação, e qualquer mudança exigiria mexer na Controller e retestar tudo à mão. Se outra tela precisasse do mesmo cálculo, o código seria duplicado. Com Service e interface, a Fase 05 só precisou de um novo método e um novo teste, executado em milissegundos e sem banco de dados.

**05. O que define um "bom cenário de teste"? Que outros cenários (casos de borda) você testaria?**

Um bom cenário testa um único comportamento, tem nome descritivo, segue Arrange-Act-Assert e é determinístico e independente dos outros testes. O valor esperado deve ser calculado de forma independente (à mão ou na calculadora), e não copiado da implementação. Além do caso típico, ele cobre os limites. Cenários que eu testaria (os marcados com ✔ já estão no projeto):

- ✔ Taxa zero (o valor final é igual ao valor base).
- ✔ Valor zero (não gera juros).
- ✔ Valores com centavos e taxas fracionárias (R$ 2.500,50 a 3,5%).
- ✔ Taxa de 100%.
- ✔ Juros compostos com 0 meses e com 1 mês (1 mês deve dar o mesmo que juros simples).
- ✔ Prazo maior (R$ 5.000,00 a 1,5% a.m. por 24 meses).
- Valor, taxa ou meses negativos: hoje o serviço aceita. O ideal é definir a regra (por exemplo, lançar `ArgumentOutOfRangeException`) e escrever esse teste antes de implementar a validação.
- Valores muito grandes, para verificar o estouro de `decimal` (`OverflowException`).
- Arredondamento para centavos, conforme a regra do banco (por exemplo, `MidpointRounding.AwayFromZero`).

**06. Por que, em sistemas financeiros, o tipo `decimal` é preferível a `double` ou `float`?**

`double` e `float` armazenam números em base 2 (padrão IEEE 754) e não representam exatamente frações decimais como 0,10. Por exemplo, `0.1 + 0.2` em `double` resulta em `0.30000000000000004`. Em finanças, esses erros pequenos se acumulam em milhares de operações e geram diferenças de centavos, inaceitáveis para contabilidade e auditoria. O `decimal` trabalha em base 10 com 28 a 29 dígitos significativos e representa valores monetários com exatidão. Por isso os métodos recebem e devolvem `decimal`, e o parâmetro `taxa` em `double` é convertido com `(decimal)taxa` antes da conta. Pelo mesmo motivo, na refatoração da Fase 05 o cálculo de juros compostos deixou de usar `Math.Pow` em `double` e passou a ser feito todo em `decimal`.

**07. Como a necessidade de tornar o código "testável" influencia a organização das classes e métodos?**

Ela empurra o código para classes pequenas, com uma responsabilidade cada (a regra de juros fica no Service, não na Controller). As dependências passam a ser explícitas e baseadas em interfaces, e não criadas "escondidas" dentro dos métodos. Os métodos tendem a ser puros: recebem entradas e devolvem um resultado, sem acessar banco, tela ou variáveis globais, como `CalcularJurosSimples(valor, taxa)`. Quando algo é difícil de testar, normalmente é sinal de acoplamento excessivo, e o próprio teste mostra onde o design precisa melhorar. O resultado é um código com nomes claros, métodos curtos e partes que podem ser trocadas sem efeito cascata.

**08. Se um teste que passava (Verde) começar a falhar (Vermelho) depois de uma alteração, isso é ruim?**

Não. É exatamente para isso que os testes automatizados existem: eles são uma rede de segurança contra regressões. A falha avisa, antes de o código chegar à produção e ao dinheiro do cliente, que a alteração quebrou um comportamento esperado. Ruim seria o erro passar despercebido. Diante da falha, é preciso analisar: ou a alteração introduziu um bug (corrige-se o código), ou a regra de negócio mudou de propósito (atualiza-se o teste de forma consciente). Na Fase 05, ao trocar `double` por `decimal`, os testes continuarem verdes foi o que deu segurança de que o resultado não tinha mudado.

**09. Como a composição de objetos (`ContaBancaria` recebendo um `Cliente`) facilita a manutenção em comparação a variáveis soltas como `string nomeCliente`?**

Os dados do cliente ficam em um único lugar, o objeto `Cliente`. Se o nome ou a UF mudam, muda-se o objeto, e não várias cópias de texto espalhadas pelo sistema, o que evita duplicação e inconsistência. Para acrescentar informações ao cliente (CPF, e-mail) basta alterar a classe `Cliente`, sem mudar a estrutura de `ContaBancaria`. O acesso fica tipado e legível (`conta.Cliente.Nome`, `conta.Agencia.Cidade`), e o compilador aponta erros de digitação. A estrutura também corresponde aos relacionamentos do banco de dados (chaves estrangeiras no Entity Framework) e permite regras que dependem do cliente ou da agência, como uma taxa por estado, recebendo o objeto inteiro.

**10. "Testar não é encontrar erros, é garantir a confiança." Explique essa frase relacionando-a à responsabilidade de quem trabalha com sistemas que manipulam dinheiro.**

Nenhum teste prova que um sistema não tem erros. O que os testes automatizados oferecem é uma evidência repetível, a cada compilação, de que as regras críticas fazem o que prometem. Em um sistema financeiro, um erro de um centavo multiplicado por milhares de contratos vira prejuízo, reclamação, processo e problema com o Banco Central, além de perda de credibilidade. Quem desenvolve esse tipo de sistema lida com o dinheiro de outras pessoas. Os testes documentam as regras (R1 e R2) com exemplos concretos, permitem evoluir e refatorar o código sem medo e dão confiança ao cliente, ao banco, à auditoria e à própria equipe de que cada centavo é calculado corretamente.

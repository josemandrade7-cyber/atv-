using System.ComponentModel.DataAnnotations;

namespace PrjFinanceiro.Models
{
    public class ContaBancaria
    {
        [Key]
        public string NumeroConta { get; set; } = string.Empty;
        public decimal Saldo { get; set; }

        // Composição de objetos: a conta "tem um" Cliente e "tem uma" Agencia
        public Cliente Cliente { get; set; } = new Cliente();
        public Agencia Agencia { get; set; } = new Agencia();
    }
}

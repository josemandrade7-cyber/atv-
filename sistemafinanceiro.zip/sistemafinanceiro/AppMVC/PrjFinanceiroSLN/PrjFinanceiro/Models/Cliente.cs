using System.ComponentModel.DataAnnotations;

namespace PrjFinanceiro.Models
{
    public class Cliente
    {
        [Key]
        public int Codigo { get; set; }
        public string Nome { get; set; } = string.Empty;
        public string EstadoUF { get; set; } = string.Empty;
    }
}

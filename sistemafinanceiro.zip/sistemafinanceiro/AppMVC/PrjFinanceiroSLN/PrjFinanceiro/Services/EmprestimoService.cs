namespace PrjFinanceiro.Services
{
    public class EmprestimoService : IEmprestimoService
    {
        public decimal CalcularJurosSimples(decimal valor, double taxa)
        {
            // Implementação da Regra R1
            // Valor Final = Valor + (Valor * Taxa)
            decimal valorJuros = valor * (decimal)taxa;
            decimal valorFinal = valor + valorJuros;

            return valorFinal;
        }

        public decimal CalcularJurosCompostos(decimal valor, double taxaMensal, int meses)
        {
            // Implementação da Regra R2
            // M = P * (1 + i)^n
            // Refatoração: o cálculo é feito inteiramente em decimal (sem passar por double),
            // capitalizando mês a mês, para não introduzir erros de arredondamento binário.
            decimal fatorMensal = 1m + (decimal)taxaMensal;
            decimal montante = valor;

            for (int mes = 1; mes <= meses; mes++)
            {
                montante *= fatorMensal;
            }

            return montante;
        }
    }
}

namespace PrjFinanceiro.Services
{
    /// <summary>
    /// Contrato dos cálculos de empréstimo do Sistema Financeiro.
    /// </summary>
    public interface IEmprestimoService
    {
        /// <summary>
        /// Regra R1 – Juros simples: ValorFinal = ValorBase + (ValorBase × Taxa).
        /// </summary>
        /// <param name="valor">Valor base do empréstimo (R$).</param>
        /// <param name="taxa">Taxa em formato decimal (ex.: 10% = 0.10).</param>
        /// <returns>Valor final do empréstimo.</returns>
        decimal CalcularJurosSimples(decimal valor, double taxa);

        /// <summary>
        /// Regra R2 – Juros compostos com capitalização mensal: M = P × (1 + i)^n.
        /// </summary>
        /// <param name="valor">Principal (P): valor do empréstimo (R$).</param>
        /// <param name="taxaMensal">Taxa por período (i) em formato decimal (ex.: 2% = 0.02).</param>
        /// <param name="meses">Número de períodos (n), em meses.</param>
        /// <returns>Montante (M): valor final do empréstimo.</returns>
        decimal CalcularJurosCompostos(decimal valor, double taxaMensal, int meses);
    }
}

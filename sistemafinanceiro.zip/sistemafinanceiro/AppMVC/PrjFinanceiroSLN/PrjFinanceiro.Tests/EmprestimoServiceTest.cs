using System;
using PrjFinanceiro.Services;
using Xunit;

namespace PrjFinanceiro.Tests
{
    public class EmprestimoServiceTest
    {
        // O xUnit cria uma nova instância da classe de teste para cada teste,
        // então cada cenário recebe um serviço "limpo".
        private readonly IEmprestimoService _service = new EmprestimoService();

        [Fact]
        public void CalcularJurosSimples_DeveRetornarValorCorreto()
        {
            // Arrange (Preparação do cenário)
            decimal valorEmprestimo = 1000m;
            double taxaJuros = 0.10; // 10%
            decimal resultadoEsperado = 1100m;

            // Act (Ação: Execução do método)
            decimal resultadoObtido = _service.CalcularJurosSimples(valorEmprestimo, taxaJuros);

            // Assert (Verificação: O resultado é o esperado?)
            Assert.Equal(resultadoEsperado, resultadoObtido);
        }

        // Cenários adicionais (casos de borda) para a regra R1
        public static TheoryData<decimal, double, decimal> CenariosJurosSimples => new()
        {
            { 0m,       0.10,  0m },          // valor zero não gera juros
            { 1000m,    0.0,   1000m },       // taxa zero mantém o valor
            { 2500.50m, 0.035, 2588.0175m },  // centavos e taxa fracionária (3,5%)
            { 1000m,    1.0,   2000m },       // taxa de 100%
        };

        [Theory]
        [MemberData(nameof(CenariosJurosSimples))]
        public void CalcularJurosSimples_CasosDeBorda(decimal valor, double taxa, decimal esperado)
        {
            decimal resultado = _service.CalcularJurosSimples(valor, taxa);

            Assert.Equal(esperado, resultado);
        }

        [Fact]
        public void CalcularJurosCompostos_DeveRetornarValorCorreto()
        {
            // Arrange: R$ 1.000,00 a 2% ao mês por 12 meses
            decimal valorEmprestimo = 1000m;
            double taxaMensal = 0.02; // 2% a.m.
            int meses = 12;
            decimal resultadoEsperado = 1268.24m; // 1000 x (1,02)^12 ≈ 1268,2418

            // Act
            decimal resultadoObtido = _service.CalcularJurosCompostos(valorEmprestimo, taxaMensal, meses);

            // Assert: comparamos em centavos (2 casas decimais)
            Assert.Equal(resultadoEsperado, Math.Round(resultadoObtido, 2));
        }

        // Cenários adicionais (casos de borda) para a regra R2
        public static TheoryData<decimal, double, int, decimal> CenariosJurosCompostos => new()
        {
            { 1000m, 0.10,  1,  1100.00m },  // 1 período: igual ao juros simples (R1)
            { 1000m, 0.0,   12, 1000.00m },  // taxa zero mantém o valor
            { 1000m, 0.02,  0,  1000.00m },  // zero meses: sem capitalização
            { 0m,    0.02,  12, 0.00m },     // valor zero
            { 5000m, 0.015, 24, 7147.51m },  // 1,5% a.m. por 24 meses
        };

        [Theory]
        [MemberData(nameof(CenariosJurosCompostos))]
        public void CalcularJurosCompostos_CasosDeBorda(decimal valor, double taxaMensal, int meses, decimal esperado)
        {
            decimal resultado = _service.CalcularJurosCompostos(valor, taxaMensal, meses);

            Assert.Equal(esperado, Math.Round(resultado, 2));
        }
    }
}
